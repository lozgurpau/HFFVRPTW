Online Resource 2: HFFVRPTW benchmark instances

This archive contains the 24 benchmark instances of the computational study (Section 5): classes R1, C1, RC1, R2, C2 and RC2, four instances each, with 100 customers, a single depot and the type A fleet. The instances are the HFFVRPTW adaptation by Paraskevopoulos et al. (2008) of the FSMVRPTW instances of Liu and Shen (1999), which derive from the instances of Solomon (1987). File r101_A1.txt corresponds to instance R101A in Table 4 and Online Resource 1; the other files follow the same naming rule.

File format (tab-separated values)
Line 1: number of customers n, L1, L2. L2 equals the due date of the depot; L1 = 0.9 L2 is the lower duration threshold of the route-duration variants.
Line 2: depot: index 0, x coordinate, y coordinate, demand, ready time, due date, service time.
Lines 3 to n + 2: customers, with the same seven columns.
Remaining lines: one line per vehicle type: capacity, fixed cost, variable cost per unit distance, number of available vehicles, volume capacity (9999, not binding in these instances).

Travel distances and travel times are the Euclidean distances between the coordinates, computed without rounding. The route-duration variants FIXED-PENALTY, SOFT and MULTILEVEL use the same files with the customer time windows removed (Section 5.3).
